#!/usr/bin/env python


from brain_games.scripts.brain_logic import brain_calc, brain_even, brain_gcd, brain_prime, brain_progression, greet


def main():
    greet
    brain_calc
    brain_even
    brain_gcd
    brain_prime
    brain_progression
