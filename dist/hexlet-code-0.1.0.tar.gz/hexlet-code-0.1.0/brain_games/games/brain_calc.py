#!/usr/bin/env python3


from brain_games.scripts.brain_logic import brain_calc, greet


def main():
    greet()
    brain_calc()
